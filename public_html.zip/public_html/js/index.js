/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

function clicPhotoCrossfit(id) {
    var txt = "photo"

    document.getElementById(txt + "Puissance").className = "icone-crossfit_secondaire opacite";
    document.getElementById(txt + "Vitesse").className = "icone-crossfit_secondaire opacite";
    document.getElementById(txt + "Souplesse").className = "icone-crossfit_secondaire opacite";
    document.getElementById(txt + "Agilite").className = "icone-crossfit_secondaire opacite";
    document.getElementById(txt + "Force").className = "icone-crossfit_secondaire opacite";
    document.getElementById(txt + "Endurance").className = "icone-crossfit_secondaire opacite";
    document.getElementById(txt + "Precision").className = "icone-crossfit_secondaire opacite";
    document.getElementById(txt + "Coordination").className = "icone-crossfit_secondaire opacite";
    document.getElementById(txt + "Equilibre").className = "icone-crossfit_secondaire opacite";

    document.getElementById(txt + id).className = "icone_crossfit hvr-bob";

    txt = "text"
    document.getElementById(txt + "Puissance").style.display = "none";
    document.getElementById(txt + "Vitesse").style.display = "none";
    document.getElementById(txt + "Souplesse").style.display = "none";
    document.getElementById(txt + "Agilite").style.display = "none";
    document.getElementById(txt + "Force").style.display = "none";
    document.getElementById(txt + "Endurance").style.display = "none";
    document.getElementById(txt + "Precision").style.display = "none";
    document.getElementById(txt + "Coordination").style.display = "none";
    document.getElementById(txt + "Equilibre").style.display = "none";

    document.getElementById(txt + id).style.display = "block";
}

function clicRubriqueVersionMobile() { /* la fonction est appelée si l'utilisateur change de rubrique avec la nav-bar */
    var x = document.getElementById("menu").selectedIndex; /* Récupère l'option choisi dans le select */
    var rubrique; /* pour stocker le nom de la rubrique en fonction du numéro de l'option */

    if (x === 0)
        rubrique = "accueil";
    if (x === 1)
        rubrique = "concept";
    if (x === 2)
        rubrique = "box";
    if (x === 3)
        rubrique = "equipe";
    if (x === 4)
        rubrique = "planning";
    if (x === 5)
        rubrique = "tarifs";
    if (x === 6)
        rubrique = "contact";
    if (x === 7)
        rubrique = "reservation";

    scrollPageVersionMobile(rubrique); /* scroll automatiquement vers la rubrque sélectionnée */
}

function scrollPageVersionMobile(id) { /* scroll automatiquement vers la rubrque donnée en paramètre */

    if (id === "accueil")
        document.getElementById("all").scrollTop = 0;

    if (id === "concept")
        document.getElementById("all").scrollTop = 1000;

    if (id === "box")
        document.getElementById("all").scrollTop = 0;

    if (id === "equipe")
        document.getElementById("all").scrollTop = 0;

    if (id === "planning")
        document.getElementById("all").scrollTop = 0;

    if (id === "tarifs")
        document.getElementById("all").scrollTop = 0;

    if (id === "contact")
        document.getElementById("all").scrollTop = 0;

    if (id === "reservation")
        document.getElementById("all").scrollTop = 0;

    console.log(document.getElementById("all").scrollTop);
}

function scrollPageVersionOrdinateur(id) { /* scroll automatiquement vers la rubrque donnée en paramètre */

    if (id === "accueil")
        document.getElementById("all").scrollTop = 0;

    if (id === "concept")
        document.getElementById("all").scrollTop = 1000;

    if (id === "box")
        document.getElementById("all").scrollTop = 0;

    if (id === "equipe")
        document.getElementById("all").scrollTop = 0;

    if (id === "planning")
        document.getElementById("all").scrollTop = 0;

    if (id === "tarifs")
        document.getElementById("all").scrollTop = 0;

    if (id === "contact")
        document.getElementById("all").scrollTop = 0;

    if (id === "reservation")
        document.getElementById("all").scrollTop = 0;

    console.log(document.getElementById("all").scrollTop);
}

function clicRubriqueVersionOrdinateur(id) { /* est appelée quand l'utilisateur clique sur une rubrique de la navbar verion PC, la rubrique en question est passée en paramètre */

    /* passe toutes les rubriques en classe inactive */
    document.getElementById("accueil").className = "nav-rubrique inactif";
    document.getElementById("concept").className = "nav-rubrique inactif";
    document.getElementById("box").className = "nav-rubrique inactif";
    document.getElementById("equipe").className = "nav-rubrique inactif";
    document.getElementById("planning").className = "nav-rubrique inactif";
    document.getElementById("tarifs").className = "nav-rubrique inactif";
    document.getElementById("contact").className = "nav-rubrique inactif";
    document.getElementById("reservation").className = "nav-rubrique inactif";

    /* passe uniquement la rubrique sélectionnée en classe active */

    if (id === "accueil")
    {
        document.getElementById("accueil").className = "nav-rubrique actif";
    }

    if (id === "concept")
    {
        document.getElementById("concept").className = "nav-rubrique actif";
    }

    if (id === "box")
    {
        document.getElementById("box").className = "nav-rubrique actif";
    }

    if (id === "equipe")
    {
        document.getElementById("equipe").className = "nav-rubrique actif";
    }

    if (id === "planning")
    {
        document.getElementById("planning").className = "nav-rubrique actif";
    }

    if (id === "tarifs")
    {
        document.getElementById("tarifs").className = "nav-rubrique actif";
    }

    if (id === "contact")
    {
        document.getElementById("contact").className = "nav-rubrique actif";
    }

    if (id === "reservation")
    {
        document.getElementById("reservation").className = "nav-rubrique actif";
    }

}


function hover_coach(x)
{
    x.style.width = "50%";
}

function sans_hover_coach(x)
{
    x.style.width = "80%";
}

function afficher_div_masque() {

    var toto = document.getElementById("toto");

    toto.style.display = "block";

}

$(function () {

    $('a[href*=#go]:not([href=#])').click(function () {

        if (location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') && location.hostname == this.hostname) {

            var target = $(this.hash);

            target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');

            if (target.length) {

                $('html,body').animate({scrollTop: target.offset().top}, 1000);

                return false;

            }

        }

    });

});

